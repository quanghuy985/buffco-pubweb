<?php

return array(
    'Requite'=>'loi'
);
