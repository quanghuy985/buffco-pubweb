<?php
return array(
    'project' => array(
        'name'        => 'Bạn chưa nhập tên dự án.',
        'description' => 'Bạn chưa nhập mô tả dự án.',
        'content'     => 'Bạn chưa nhập nội dung dự án.',
    ),
    'page'    => array(
        'name'    => 'Bạn chưa nhập tên trang.',
        'keyword' => 'Bạn chưa nhập keyword.',
        'tag'     => 'Bạn chưa nhập tag.',
        'slug'    => 'Bạn chưa nhập slug.'
    ),
);