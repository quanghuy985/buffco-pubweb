<?php
return array(
    'locked'         => 'Tài khoản của bạn đã bị khoá!',
    'login_error'    => 'Email hoặc mật khẩu sai !',
    'back_to_login'  => 'Quay về trang đăng nhập?',
    'email_exist'    => 'Email không tôn tại trên hệ thống!',
    'forgot_success' => 'Bạn check email để lấy lại mật khẩu!'
);