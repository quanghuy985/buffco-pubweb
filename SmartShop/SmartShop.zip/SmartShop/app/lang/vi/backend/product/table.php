<?php
return array(
    'name'     => 'Tên sản phẩm',
    'code'     => 'Mã sản phẩm',
    'group'    => 'Nhóm',
    'price'    => 'Giá',
    'sales'    => 'Khuyến mãi',
    'quantity' => 'Số lượng',
    'sold'     => 'Đã bán'
);