<?php
return array(
    'management' => 'Quản lý sản phẩm',
    'create'     => 'Thêm mới sản phẩm',
    'product'    => 'Sản phẩm',

);
