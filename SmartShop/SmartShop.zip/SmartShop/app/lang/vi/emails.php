<?php

return array(
    'forgot_password_title' => 'Lấy lại mật khẩu.',
    'forgot_password_content' => 'Bấm vào đường dẫn để thay đổi mật khẩu :'
);
