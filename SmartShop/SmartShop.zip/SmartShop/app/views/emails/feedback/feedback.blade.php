<strong>Nội dung phản ánh : </strong><br>
{{$noidung}}
<br>
<strong>Trả lời của chúng tôi :</strong><br>
{{$traloi}}