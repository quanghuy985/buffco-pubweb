<?php

namespace BackEnd;

use DB;

class ProductModel extends \Eloquent {
    
}
