<?php

namespace FontEnd;

use Session,
    Input,
    Cookie,
    Redirect,
    View;

class FeedbacksController extends \BaseController {
    
}
