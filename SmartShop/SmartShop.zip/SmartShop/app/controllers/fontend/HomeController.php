<?php

namespace FontEnd;

use Session,
    Input,
    Cookie,
    Redirect,
    View;

class HomeController extends \BaseController {
    
}
